﻿namespace Domain
{
    public class Color
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string colorName { get; set; }

    }
}
